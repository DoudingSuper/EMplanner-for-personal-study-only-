This class was clone from another repository :
https://github.com/Polidea/android-zoom-view.git

and was developed by :
Maciej Oczko ( literator )